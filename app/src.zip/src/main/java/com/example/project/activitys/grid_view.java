package com.example.project.activitys;

import android.os.Bundle;
import android.widget.GridView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.project.R;
import com.example.project.adapters.personAdapters;
import com.example.project.models.persone;

import java.util.ArrayList;

public class grid_view extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_grid_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        GridView gv;
        personAdapters adapter;
        ArrayList<persone> personeArrayList;
        gv = findViewById(R.id.gv_employees);
        personeArrayList = new ArrayList<>();
        personeArrayList.add(new persone(1 , "Mohammed" , 4 , 4000f , 50 , R.drawable.extraction));
        personeArrayList.add(new persone(1 , "Ali" , 2 , 6000f , 60 , R.drawable.mv));
        personeArrayList.add(new persone(1 , "Hassan" , 3 , 3000f , 30 , R.drawable.avatar_detail));
        adapter = new personAdapters(grid_view.this , personeArrayList);
        gv.setAdapter(adapter);
    }
}