package com.example.project.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.core.view.LayoutInflaterCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.core.widget.TextViewCompat;

import com.example.project.R;
import com.example.project.models.persone;

import java.util.ArrayList;

public class personAdapters extends BaseAdapter {
    Context context;
    ArrayList<persone> personeArrayList = new ArrayList<>();
    LayoutInflater inflater;

    public personAdapters(Context context, ArrayList<persone> personeArrayList) {
        this.context = context;
        this.personeArrayList = personeArrayList;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return personeArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return personeArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return personeArrayList.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View root = inflater.inflate(R.layout.employee_persone_design , null);
        ImageView person_img =root.findViewById(R.id.profile_image);
        TextView person_name =root.findViewById(R.id.persone_name);
        RatingBar rating =root.findViewById(R.id.rating);
        TextView tv_price = root.findViewById(R.id.tv_price);
        TextView tv_hour_price = root.findViewById(R.id.tv_hour);

        person_img.setImageResource(personeArrayList.get(i).getImage());
        person_name.setText(personeArrayList.get(i).getName());
        rating.setRating((float) personeArrayList.get(i).getRating());
        tv_price.setText( personeArrayList.get(i).getPrice()+"");
        tv_hour_price.setText( personeArrayList.get(i).getHour_price()+"");

        return root;
    }
}
