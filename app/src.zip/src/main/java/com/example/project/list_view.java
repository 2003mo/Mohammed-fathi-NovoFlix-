package com.example.project;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.project.adapters.personAdapters;
import com.example.project.models.persone;

import java.util.ArrayList;

public class list_view extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list_view);
        ListView lv;
        personAdapters adapter;
        ArrayList<persone> personeArrayList;
        lv = findViewById(R.id.lv_employees);
        personeArrayList = new ArrayList<>();
        personeArrayList.add(new persone(1 , "Mohammed" , 4 , 4000f , 50 , R.drawable.extraction));
        personeArrayList.add(new persone(1 , "Ali" , 2 , 6000f , 60 , R.drawable.mv));
        personeArrayList.add(new persone(1 , "Hassan" , 3 , 3000f , 30 , R.drawable.avatar_detail));
        adapter = new personAdapters(list_view.this , personeArrayList);
        lv.setAdapter(adapter);
    }
}