package com.example.project.models;

public class persone {
    private int id;
    private String name;
    private int rating;
    private float price;
    private int hour_price;
    private int image;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public persone(int id, String name, int rating, float price, int hour_price, int image) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.price = price;
        this.hour_price = hour_price;
        this.image = image;
    }

    public persone() {
    }

    public persone(int id, String name, int rating, float price, int hour_price) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.price = price;
        this.hour_price = hour_price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getHour_price() {
        return hour_price;
    }

    public void setHour_price(int hour_price) {
        this.hour_price = hour_price;
    }
}
